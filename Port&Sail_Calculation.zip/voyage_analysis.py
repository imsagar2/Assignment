
import pandas as pd
from datetime import timedelta
from geopy.distance import geodesic
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
data = pd.read_csv('voyages.csv')

# Convert dateStamp and timeStamp to datetime
data['event_time'] = pd.to_datetime('1899-12-30') + pd.to_timedelta(data['dateStamp'], unit='D') + pd.to_timedelta(data['timeStamp'] * 24, unit='H')

# Sort data by event_time
data = data.sort_values('event_time')

# Calculate duration and distances
data['prev_event_time'] = data['event_time'].shift(1)
data['duration'] = (data['event_time'] - data['prev_event_time']).dt.total_seconds()

data['prev_lat'] = data['lat'].shift(1)
data['prev_lon'] = data['lon'].shift(1)

def calculate_distance(row):
    if pd.notnull(row['prev_lat']) and pd.notnull(row['prev_lon']):
        return geodesic((row['lat'], row['lon']), (row['prev_lat'], row['prev_lon'])).nautical
    return 0

data['distance_travelled'] = data.apply(calculate_distance, axis=1)

# Filter relevant events
filtered_data = data[data['event'].isin(['SOSP', 'EOSP'])]

# Plot timeline of events
plt.figure(figsize=(15, 10))
sns.lineplot(x='event_time', y='duration', data=filtered_data, marker='o')
plt.xlabel('Event Time')
plt.ylabel('Duration (seconds)')
plt.title('Voyage Timeline')
plt.show()
