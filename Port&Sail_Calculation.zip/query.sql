
WITH voyage_data AS (
    SELECT
        id,
        event,
        DATE_ADD('1899-12-30', INTERVAL dateStamp DAY) + INTERVAL timeStamp*24 HOUR AS event_time,
        voyage_From,
        lat,
        lon,
        imo_num,
        voyage_Id
    FROM voyages
    WHERE voyage_Id = '6' AND allocatedVoyageId IS NULL
),
segmented_data AS (
    SELECT
        *,
        LAG(event_time) OVER (PARTITION BY voyage_Id ORDER BY event_time) AS prev_event_time,
        LAG(lat) OVER (PARTITION BY voyage_Id ORDER BY event_time) AS prev_lat,
        LAG(lon) OVER (PARTITION BY voyage_Id ORDER BY event_time) AS prev_lon
    FROM voyage_data
)
SELECT
    id,
    event,
    event_time,
    voyage_From,
    lat,
    lon,
    imo_num,
    voyage_Id,
    TIMESTAMPDIFF(SECOND, prev_event_time, event_time) AS duration,
    ST_Distance_Sphere(point(lon, lat), point(prev_lon, prev_lat)) / 1852 AS distance_travelled -- distance in nautical miles
FROM segmented_data
WHERE event IN ('SOSP', 'EOSP')
ORDER BY event_time;
