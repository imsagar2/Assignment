
import pandas as pd
import numpy as np

# Load data
data = pd.read_csv('transactions.csv')

# Data preprocessing
data['date'] = pd.to_datetime(data['date'])
data.dropna(inplace=True)

# Calculate statistical metrics
category_stats = data.groupby('category')['amount'].agg(['mean', 'median', 'std']).reset_index()

# Function to detect anomalies using Z-score
def detect_anomalies_zscore(row, stats):
    mean = stats.loc[stats['category'] == row['category'], 'mean'].values[0]
    std = stats.loc[stats['category'] == row['category'], 'std'].values[0]
    z_score = (row['amount'] - mean) / std
    if abs(z_score) > 3:
        return True, z_score
    return False, z_score

# Apply anomaly detection
data['is_anomaly'] = data.apply(lambda row: detect_anomalies_zscore(row, category_stats)[0], axis=1)
data['z_score'] = data.apply(lambda row: detect_anomalies_zscore(row, category_stats)[1], axis=1)

# Generate anomaly report
anomaly_report = data[data['is_anomaly']].copy()
anomaly_report['reason_for_anomaly'] = anomaly_report.apply(lambda row: f"Z-score: {row['z_score']:.2f}", axis=1)
anomaly_report = anomaly_report[['transaction_id', 'date', 'category', 'amount', 'reason_for_anomaly']]

# Summary statistics
summary_stats = anomaly_report.groupby('category').size().reset_index(name='anomaly_count')

# Save reports
anomaly_report.to_csv('anomaly_report.csv', index=False)
summary_stats.to_csv('summary_stats.csv', index=False)

print("Anomaly detection completed. Reports generated.")
